import { api } from './client';

export type CandidateQuery = {
  search?: string;
  developerType?: string;
  page?: number;
  limit?: number;
};

function toQueryString(params: Record<string, any>) {
  const parts = Object.entries(params)
    .filter(([, v]) => v !== undefined && v !== null && v !== '')
    .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(String(v))}`);
  return parts.length ? `?${parts.join('&')}` : '';
}

export const candidateService = {
  list: (query: CandidateQuery = {}) => api.get(`/candidates${toQueryString(query)}`),
  getById: (id: string) => api.get(`/candidates/${id}`),
  getMyProfile: () => api.get('/candidates/me'),
  updateMyProfile: (payload: any) => api.put('/candidates/me', payload),
};
